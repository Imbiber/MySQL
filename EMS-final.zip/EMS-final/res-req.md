# Employee Management API Documentation

## Overview
This API provides endpoints for managing organizations, managers, and employees. The endpoints allow creating, retrieving, updating, and deleting records.

---
## Organisation Endpoints

### Create Organisation
**Endpoint:** `POST /createOrg`

**Request Body:**
```json
{
  "name": "FutureTech",
  "description": "AI-powered solutions company",
  "address": "456 Future Street, AI Valley, CA"
}
```
**Response:**
```json
{
  "id": 3,
  "name": "FutureTech",
  "description": "AI-powered solutions company",
  "address": "456 Future Street, AI Valley, CA",
  "createdAt": "2025-03-17T12:00:00.000Z"
}
```

### Get All Organisations
**Endpoint:** `GET /getAllOrganisations`

**Response:**
```json
[
  {
    "id": 1,
    "name": "TechCorp",
    "description": "Leading technology solutions provider.",
    "address": "123 Tech Ave, Silicon Valley, CA"
  },
  {
    "id": 2,
    "name": "InnovateCorp",
    "description": "Pioneers in cutting-edge technology and innovative solutions.",
    "address": "789 Innovation Drive, Tech Valley, CA"
  }
]
```

### Get Organisation Details
**Endpoint:** `GET /getOrgDetail/{id}`

**Response:**
```json
{
  "id": 1,
  "name": "TechCorp",
  "description": "Leading technology solutions provider.",
  "address": "123 Tech Ave, Silicon Valley, CA"
}
```

### Update Organisation
**Endpoint:** `PUT /updateOrgDetails`

**Request Body:**
```json
{
  "id": 1,
  "description": "Advanced technology solutions",
  "address": "999 Tech Ave, Silicon Valley, CA"
}
```
**Response:**
```json
{
  "message": "Organisation updated successfully"
}
```

### Delete Organisation
**Endpoint:** `DELETE /deleteOrg`

**Request Body:**
```json
{
  "id": 2
}
```
**Response:**
```json
{
  "message": "Organisation deleted successfully"
}
```

---
## Manager Endpoints

### Create Manager
**Endpoint:** `POST /createManager`

**Request Body:**
```json
{
  "name": "Alice Johnson",
  "email": "alice.johnson@futuretech.com",
  "organization_id": 1,
  "details": "Head of AI Development"
}
```
**Response:**
```json
{
  "id": 6,
  "name": "Alice Johnson",
  "email": "alice.johnson@futuretech.com",
  "organization_id": 1,
  "details": "Head of AI Development",
  "createdAt": "2025-03-17T12:05:00.000Z"
}
```

### Get All Managers
**Endpoint:** `GET /getAllManagers`

**Response:**
```json
[
  {
    "id": 1,
    "name": "Jane Doe",
    "email": "jane.doe@techcorp.com",
    "details": "Head of Software Development",
    "organization_id": 1
  },
  {
    "id": 5,
    "name": "Elisa Martinez",
    "email": "elisa.martinez@innovatecorp.com",
    "details": "Chief Technology Officer",
    "organization_id": 2
  }
]
```

### Get Manager Details
**Endpoint:** `GET /getManagerDetail/{id}`

**Response:**
```json
{
  "id": 1,
  "name": "Jane Doe",
  "email": "jane.doe@techcorp.com",
  "details": "Head of Software Development",
  "organization_id": 1
}
```

### Update Manager
**Endpoint:** `PUT /updateManagerDetails`

**Request Body:**
```json
{
  "id": 1,
  "name": "Alice Johnson",
  "email": "alice.j@futuretech.com",
  "details": "CTO - FutureTech"
}
```
**Response:**
```json
{
  "message": "Manager updated successfully"
}
```

### Delete Manager
**Endpoint:** `DELETE /deleteManager`

**Request Body:**
```json
{
  "id": 5
}
```
**Response:**
```json
{
  "message": "Manager deleted successfully"
}
```

---
## Employee Endpoints

### Create Employee
**Endpoint:** `POST /createEmployee`

**Request Body:**
```json
{
  "name": "Robert Brown",
  "email": "robert.brown@futuretech.com",
  "position": "AI Engineer",
  "details": "Specializing in deep learning",
  "manager_id": 1,
  "organization_id": 1
}
```
**Response:**
```json
{
  "id": 8,
  "name": "Robert Brown",
  "email": "robert.brown@futuretech.com",
  "position": "AI Engineer",
  "details": "Specializing in deep learning",
  "manager_id": 1,
  "organization_id": 1,
  "createdAt": "2025-03-17T12:10:00.000Z"
}
```

### Get All Employees
**Endpoint:** `GET /getAllEmployees`

**Response:**
```json
[
  {
    "id": 6,
    "name": "Tim Brook",
    "email": "tim.brook@techcorp.com",
    "position": "Network Engineer",
    "details": "Working on Cryptography",
    "manager_id": 1,
    "organization_id": 1
  }
]
```

### Get Employee Details
**Endpoint:** `GET /getEmployeeDetail/{id}`

**Response:**
```json
{
  "id": 6,
  "name": "Tim Brook",
  "email": "tim.brook@techcorp.com",
  "position": "Network Engineer",
  "details": "Working on Cryptography",
  "manager_id": 1,
  "organization_id": 1
}
```

### Update Employee
**Endpoint:** `PUT /updateEmployeeDetails`

**Request Body:**
```json
{
  "id": 6,
  "position": "Security Engineer",
  "details": "Now focusing on cybersecurity"
}
```
**Response:**
```json
{
  "message": "Employee updated successfully"
}
```

### Delete Employee
**Endpoint:** `DELETE /deleteEmployee`

**Request Body:**
```json
{
  "id": 7
}
```
**Response:**
```json
{
  "message": "Employee deleted successfully"
}
```
