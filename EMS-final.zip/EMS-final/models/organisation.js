const { DataTypes } = require('sequelize');
const sequelize = require('./db');

const Organisation = sequelize.define('Organisation', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.STRING,
  },
  address: {
    type: DataTypes.STRING,
  },
 
});

module.exports = Organisation;