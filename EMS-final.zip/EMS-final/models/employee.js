const { DataTypes } = require('sequelize');
const sequelize = require('./db');
const Manager = require('./manager');
const Organisation = require('./organisation');

const Employee = sequelize.define('Employee', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  position: {
    type: DataTypes.STRING,
  },
  details: {
    type: DataTypes.STRING,
  },
  manager_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Manager,
      key: 'id',
    },
  },
  organization_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Organisation,
      key: 'id',
    },
  },
});

module.exports = Employee;