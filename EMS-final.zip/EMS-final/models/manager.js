const { DataTypes } = require('sequelize');
const sequelize = require('./db');
const Organisation = require('./organisation');

const Manager = sequelize.define('Manager', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  details: {
    type: DataTypes.STRING,
  },
  organization_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Organisation,
      key: 'id',
    },
  },
});

module.exports = Manager;