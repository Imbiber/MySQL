const express = require('express');
const app = express();
const sequelize = require('./models/db'); 
require('dotenv').config();

const organisationRoutes = require('./routes/organisationRoutes');
const managerRoutes = require('./routes/managerRoutes');
const employeeRoutes = require('./routes/employeeRoutes');


app.use(express.json());


app.get('/', (req, res) => {
  res.send(`
    <h1>Employee Management System API</h1>
    <ul>
      <li><a href="http://localhost:3000/getAllOrganisations">Get All Organisations (GET)</a></li>
      <li><a href="http://localhost:3000/createOrg">Create Organisation (POST)</a></li>
      <li><a href="http://localhost:3000/updateOrgDetails">Update Organisation (PUT)</a></li>
      <li><a href="http://localhost:3000/getOrgDetail/:id">Get Organisation Details (GET)</a></li>
      <li><a href="http://localhost:3000/deleteOrg">Delete Organisation (DELETE)</a></li>
      <li><a href="http://localhost:3000/getAllManagers">Get All Managers (GET)</a></li>
      <li><a href="http://localhost:3000/createManager">Create Manager (POST)</a></li>
      <li><a href="http://localhost:3000/updateManagerDetails">Update Manager (PUT)</a></li>
      <li><a href="http://localhost:3000/getManagerDetail/:id">Get Manager Details (GET)</a></li>
      <li><a href="http://localhost:3000/deleteManager">Delete Manager (DELETE)</a></li>
      <li><a href="http://localhost:3000/getAllEmployees">Get All Employees (GET)</a></li>
      <li><a href="http://localhost:3000/createEmployee">Create Employee (POST)</a></li>
      <li><a href="http://localhost:3000/updateEmployeeDetails">Update Employee (PUT)</a></li>
      <li><a href="http://localhost:3000/getEmployeeDetail/:id">Get Employee Details (GET)</a></li>
      <li><a href="http://localhost:3000/deleteEmployee">Delete Employee (DELETE)</a></li>
    </ul>
  `);
});


app.use('/', organisationRoutes);
app.use('/', managerRoutes);
app.use('/', employeeRoutes);


sequelize.authenticate()
  .then(() => {
    console.log('Connection has been established successfully.');
    return sequelize.sync();
  })
  .then(() => {
    console.log('Database is synchronized');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
  });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});