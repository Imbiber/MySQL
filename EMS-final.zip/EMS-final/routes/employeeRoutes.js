const express = require('express');
const router = express.Router();
const Employee = require('../models/employee');

// Create an employee
router.post('/createEmployee', async (req, res) => {
  try {
    const employee = await Employee.create(req.body);
    res.status(201).json({ id: employee.id, message: "Employee created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update Employee details
router.put('/updateEmployeeDetails', async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.body.id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    await employee.update(req.body);
    res.json({ message: "Employee details updated successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete Employee
router.delete('/deleteEmployee', async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.body.id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    await employee.destroy();
    res.json({ message: "Employee deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Employee details
router.get('/getEmployeeDetail/:id', async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    res.json(employee);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get details of all employees
router.get('/getAllEmployees', async (req, res) => {
  try {
    const employees = await Employee.findAll();
    res.json(employees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;