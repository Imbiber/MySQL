const express = require('express');
const router = express.Router();
const Manager = require('../models/manager');

// Create a manager
router.post('/createManager', async (req, res) => {
  try {
    const manager = await Manager.create(req.body);
    res.status(201).json({ id: manager.id, message: "Manager created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update Manager details
router.put('/updateManagerDetails', async (req, res) => {
  try {
    const manager = await Manager.findByPk(req.body.id);
    if (!manager) {
      return res.status(404).json({ error: 'Manager not found' });
    }
    await manager.update(req.body);
    res.json({ message: "Manager details updated successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Manager details
router.get('/getManagerDetail/:id', async (req, res) => {
  try {
    const manager = await Manager.findByPk(req.params.id);
    if (!manager) {
      return res.status(404).json({ error: 'Manager not found' });
    }
    res.json(manager);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
// Get details of all managers
router.get('/getAllManagers', async (req, res) => {
  try {
    const managers = await Manager.findAll();
    res.json(managers);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// Delete Manager
router.delete('/deleteManager', async (req, res) => {
  try {
    const manager = await Manager.findByPk(req.body.id);
    if (!manager) {
      return res.status(404).json({ error: 'Manager not found' });
    }
    await manager.destroy();
    res.json({ message: "Manager deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;