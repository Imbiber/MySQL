const express = require('express');
const router = express.Router();
const Organisation = require('../models/organisation');

// Create an organization
router.post('/createOrg', async (req, res) => {
  try {
    const organisation = await Organisation.create(req.body);
    res.status(201).json({ id: organisation.id, message: "Organization created successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update organization details
router.put('/updateOrgDetails', async (req, res) => {
  try {
    const organisation = await Organisation.findByPk(req.body.id);
    if (!organisation) {
      return res.status(404).json({ error: 'Organisation not found' });
    }
    await organisation.update(req.body);
    res.json({ message: "Organization details updated successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get organization details
router.get('/getOrgDetail/:id', async (req, res) => {
  try {
    const organisation = await Organisation.findByPk(req.params.id);
    if (!organisation) {
      return res.status(404).json({ error: 'Organisation not found' });
    }
    res.json(organisation);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get details of all organisations
router.get('/getAllOrganisations', async (req, res) => {
  try {
    const organisations = await Organisation.findAll();
    res.json(organisations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete organisation
router.delete('/deleteOrg', async (req, res) => {
  try {
    const organisation = await Organisation.findByPk(req.body.id);
    if (!organisation) {
      return res.status(404).json({ error: 'Organisation not found' });
    }
    await organisation.destroy();
    res.json({ message: "Organization deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
